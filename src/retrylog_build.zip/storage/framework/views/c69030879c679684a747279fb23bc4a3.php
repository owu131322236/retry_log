<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" py-5 @[480px]:px-4 @[480px]:py-3">
        <div
            class="px-8 max-w-[1100px] mx-auto my-8 bg-center bg-no-repeat bg-cover flex justify-between items-center overflow-hidden bg-gradient-to-r from-pink-600 from- via-rose-600 via- to-red-500 to- rounded-2xl @[480px]:rounded-xl min-h-[218px]">
            <div class="flex flex-col items-start justify-center">
                <p class="text-white text-2xl font-bold leading-tight tracking-[-0.015em] px-6 pb-6">Start Your New Challenge</p>
                <p class="text-white text-sm font-normal leading-normal tracking-[0.015em] px-6 pb-6">何度続かなくてもまた始めようとする気持ちがあるなら、それは最高の強みです。ここは何度でも始められる場所。今日のあなたの新しい挑戦を、残していきましょう。</p>
            </div>
            <Button id="open" class="p-5  h-full whitespace-nowrap rounded-2xl bg-white text-red-700 shadow-lg hover:scale-105 transition-all">
                ＋ 新しいチャレンジを始める
            </Button>
        </div>
        <?php if (isset($component)) { $__componentOriginalebbec743aa5c45c4aef0a29f2a6e952b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalebbec743aa5c45c4aef0a29f2a6e952b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.challenges.challenge-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('challenges.challenge-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalebbec743aa5c45c4aef0a29f2a6e952b)): ?>
<?php $attributes = $__attributesOriginalebbec743aa5c45c4aef0a29f2a6e952b; ?>
<?php unset($__attributesOriginalebbec743aa5c45c4aef0a29f2a6e952b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalebbec743aa5c45c4aef0a29f2a6e952b)): ?>
<?php $component = $__componentOriginalebbec743aa5c45c4aef0a29f2a6e952b; ?>
<?php unset($__componentOriginalebbec743aa5c45c4aef0a29f2a6e952b); ?>
<?php endif; ?>
    </div>
    <!-- ダミーデータ -->
    <?php
    $challenges = [
    (object)['title' => '毎日ランニング', 'is_completed' => false],
    (object)['title' => '30日スクワットチャレンジ', 'is_completed' => true],
    (object)['title' => '水を1日2L飲む', 'is_completed' => false],
    (object)['title' => '毎朝の瞑想', 'is_completed' => true],
    (object)['title' => '読書30分', 'is_completed' => true],
    (object)['title' => '新しいレシピを試す', 'is_completed' => false],
    (object)['title' => '毎日感謝日記を書く', 'is_completed' => true],
    (object)['title' => '毎日英単語を覚える', 'is_completed' => false],
    ];
    ?>

    <div class="mt-5 mx-10">
        <h2 class="text-2xl font-bold text-gray-800 m-5">進行中のチャレンジ</h2>
        <div class="bg-gradient-to-r from-pink-600 from- via-rose-600 via- to-red-500 to- rounded-full h-2 w-[100px]"></div>
        <p class="text-sm text-gray-500 m-5">続けているチャレンジがここに表示されます。ボタンを押して今日の成功を記録しましょう！</p>
    </div>
    <div class="overflow-x-auto">
        <div class="flex space-x-8 px-10 py-5">
            <?php $__currentLoopData = $ongoingChallenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal8eb283993c6416b3686aa5599c2ffc29 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8eb283993c6416b3686aa5599c2ffc29 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.challenges.challenge-ongoing-card','data' => ['challenge' => $challenge]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('challenges.challenge-ongoing-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['challenge' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($challenge)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8eb283993c6416b3686aa5599c2ffc29)): ?>
<?php $attributes = $__attributesOriginal8eb283993c6416b3686aa5599c2ffc29; ?>
<?php unset($__attributesOriginal8eb283993c6416b3686aa5599c2ffc29); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8eb283993c6416b3686aa5599c2ffc29)): ?>
<?php $component = $__componentOriginal8eb283993c6416b3686aa5599c2ffc29; ?>
<?php unset($__componentOriginal8eb283993c6416b3686aa5599c2ffc29); ?>
<?php endif; ?>
            `<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="flex justify-between items-center mt-10 mx-10">
        <div>
            <h2 class="text-2xl font-bold text-gray-800 m-5">達成済みチャレンジ</h2>
            <div class="bg-gradient-to-r from-pink-600 from- via-rose-600 via- to-red-500 to- rounded-full h-2 w-[100px] mb-5"></div>
            <p class="text-sm text-gray-500 m-5">過去に達成したチャレンジがここに表示されます。一度失敗しても、再挑戦して成功を収めましょう！</p>
        </div>
        <a class="text-medium font-bold text-blue-600 hover:underline transition-all duration-300 ease-out transform hover:translate-x-2" href="<?php echo e(route('challenge-all')); ?>">全ての達成済みチャレンジ→</a>
    </div>
    <div class="overflow-x-auto">
        <div class="flex space-x-8 px-10 py-5">
            <?php $__currentLoopData = $endedChallenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endedchallenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginale7c6c5b095aff19705cfcd404a7dcf8d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7c6c5b095aff19705cfcd404a7dcf8d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.challenges.challenge-completed-card','data' => ['endedchallenge' => $endedchallenge]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('challenges.challenge-completed-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['endedchallenge' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($endedchallenge)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7c6c5b095aff19705cfcd404a7dcf8d)): ?>
<?php $attributes = $__attributesOriginale7c6c5b095aff19705cfcd404a7dcf8d; ?>
<?php unset($__attributesOriginale7c6c5b095aff19705cfcd404a7dcf8d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7c6c5b095aff19705cfcd404a7dcf8d)): ?>
<?php $component = $__componentOriginale7c6c5b095aff19705cfcd404a7dcf8d; ?>
<?php unset($__componentOriginale7c6c5b095aff19705cfcd404a7dcf8d); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
    <script>
        const openBtn = document.getElementById("open");
        const modal = document.getElementById("modal");
        const closeBtn = document.getElementById("close");
        const addHabitBtn = document.getElementById("addHabit");
        openBtn.addEventListener("click", () => {
            modal.classList.remove("hidden");
        });
        closeBtn.addEventListener("click", () => {
            modal.classList.add("hidden");
        });
        //チャレンジカードのオプションメニュー
        document.querySelectorAll('.options-button').forEach(button => {
            button.addEventListener('click', function() {
                const parent = this.parentElement;
                const menu = parent.querySelector('.options-menu');
                if (menu.classList.contains('hidden')) {
                    menu.classList.remove('hidden');
                    setTimeout(() => menu.classList.remove('opacity-0'), 10);
                }
                menu.addEventListener('mouseleave', function handleMouseLeave() {
                    menu.classList.add('opacity-0');
                    setTimeout(() => menu.classList.add('hidden'), 10);
                    menu.removeEventListener('mouseleave', handleMouseLeave);
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/challenges/index.blade.php ENDPATH**/ ?>