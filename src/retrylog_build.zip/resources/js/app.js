import './bootstrap';
import './reactions';  
import './replyform';
import './link';
import './postform';
import './navigation';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
