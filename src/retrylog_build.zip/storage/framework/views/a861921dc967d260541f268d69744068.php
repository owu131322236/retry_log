<!-- ポストとコメントとの共通ページ -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" flex flex-wrap justify-center gap-x-10 my-10">
        <div class="flex flex-col w-3/5">
            <!-- メイン投稿 -->
            <?php if (isset($component)) { $__componentOriginald1ab7500d9584180d45f67b6091c34d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald1ab7500d9584180d45f67b6091c34d5 = $attributes; } ?>
<?php $component = App\View\Components\Posts\PostDetail::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('posts.post-detail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Posts\PostDetail::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($target)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald1ab7500d9584180d45f67b6091c34d5)): ?>
<?php $attributes = $__attributesOriginald1ab7500d9584180d45f67b6091c34d5; ?>
<?php unset($__attributesOriginald1ab7500d9584180d45f67b6091c34d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald1ab7500d9584180d45f67b6091c34d5)): ?>
<?php $component = $__componentOriginald1ab7500d9584180d45f67b6091c34d5; ?>
<?php unset($__componentOriginald1ab7500d9584180d45f67b6091c34d5); ?>
<?php endif; ?>
            <!-- 返信ポスト -->
            <div class="pl-4 border-l-2 border-gray-300 m-8">
                <div class="flex flex-col gap-3 mx-5">
                    <?php $__currentLoopData = $target->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginaleaa7a4d7a4501e730be6bbdd94faf6f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleaa7a4d7a4501e730be6bbdd94faf6f0 = $attributes; } ?>
<?php $component = App\View\Components\Posts\PostReply::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('posts.post-reply'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Posts\PostReply::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['comment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($comment)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleaa7a4d7a4501e730be6bbdd94faf6f0)): ?>
<?php $attributes = $__attributesOriginaleaa7a4d7a4501e730be6bbdd94faf6f0; ?>
<?php unset($__attributesOriginaleaa7a4d7a4501e730be6bbdd94faf6f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleaa7a4d7a4501e730be6bbdd94faf6f0)): ?>
<?php $component = $__componentOriginaleaa7a4d7a4501e730be6bbdd94faf6f0; ?>
<?php unset($__componentOriginaleaa7a4d7a4501e730be6bbdd94faf6f0); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="sticky bottom-0 bg-gray-100/90 z-10 my-5">
                <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex items-start space-x-4 py-4">
                    <img
            src="<?php echo e(auth()->user()->icon->path ?? asset('images/icons/default.jpg')); ?>"
            alt="User Icon"
            class="w-10 h-10 rounded-full border object-cover"/>
                        <form action="<?php echo e(route('comment.store')); ?>" method="POST" class="w-full">
                            <div class="flex-1 flex items-center space-x-2">
                            
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="target_type" id="inputTargetType" value="<?php echo e($target->getMorphClass()); ?>">
                                <input type="hidden" name="target_id" id="inputTargetId" value="<?php echo e($target->id); ?>">
                                <input type="text" name="content" class="w-full bg-background-light dark:bg-background-dark border border-gray-300 dark:border-border-dark rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-text-light dark:text-text-dark" placeholder="Post your reply" type="text" />
                                <button type="submit" class="bg-blue-500 border border-gray-300 text-white font-semibold py-2 px-4 rounded-full hover:opacity-90 transition-opacity">
                                    Reply
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex flex-col justify-start gap-5">
            <div>
                <div class="bg-gradient-to-r from-pink-600 from- via-rose-600 via- to-red-500 to- rounded-full h-2 w-[50px]"></div>
                <h2 class="ext-[#0d0d1c] tracking-light text-[28px] font-bold leading-tight text-left py-3">投稿者のプロフィール</h2>
            </div>
            <?php if (isset($component)) { $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $attributes; } ?>
<?php $component = App\View\Components\ProfileCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProfileCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profileUser),'isOwnProfile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isOwnProfile),'isFollowing' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isFollowing),'retryRate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($retryRate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $attributes = $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $component = $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/post-show.blade.php ENDPATH**/ ?>