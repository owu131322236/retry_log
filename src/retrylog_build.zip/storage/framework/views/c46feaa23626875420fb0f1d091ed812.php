<?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if (isset($component)) { $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.posts.post-card','data' => ['post' => $post]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('posts.post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $attributes = $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $component = $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/html/resources/views/partials/timeline-posts.blade.php ENDPATH**/ ?>