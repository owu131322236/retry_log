<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="h-48 fixed">
        <img class="w-full h-48 object-cover" src="https://kenblo.com/wp-content/uploads/2018/03/twitter-header-nature006.jpg" alt="Banner Image">
        <div class="absolute bottom-0 w-full h-48 bg-gradient-to-b from-transparent to-gray-100"></div>
    </div>
    <div class="mt-7 p-4 flex justify-around z-10 relative">
        <?php if (isset($component)) { $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2 = $attributes; } ?>
<?php $component = App\View\Components\ProfileCard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ProfileCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profileUser),'isOwnProfile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isOwnProfile),'isFollowing' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isFollowing),'retryRate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($retryRate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $attributes = $__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__attributesOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2)): ?>
<?php $component = $__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2; ?>
<?php unset($__componentOriginal6d78bd9b89cd9e407664fe9b1900d7d2); ?>
<?php endif; ?>
        <div class="flex flex-col w-2/3">
            <div class="bg-gradient-to-r from-pink-600 from- via-rose-600 via- to-red-500 to- rounded-full h-2 w-[50px]"></div>
            <h2 class="text-[#0d0d1c] tracking-light text-[28px] font-bold leading-tight text-left pb-3 pt-5 "><?php echo e($profileUser->name); ?>のProfile</h2>
            <div id="timeSelector" class="relative bg-gray-900/5 shadow-lg border border border-gray-300/30 backdrop-blur-lg rounded-full h-fit w-fit m-5 p-2 flex gap-2">
                <div id="indicator" class="absolute top-1/2 left-2 h-4/5 w-1/4 rounded-full bg-gray-900 transition-all duration-300 -translate-y-1/2"></div>
                <!-- z軸の方向に手前に動かす -->
                <button data-target="posts" class="relative z-10 px-6 py-2 rounded-full text-gray-800">投稿</button>
                <button data-target="likes" class="relative z-10 px-6 py-2 rounded-full text-gray-800">いいね</button>
                <button data-target="challenges" class="relative z-10 px-6 py-2 rounded-full text-gray-800">チャレンジ</button>
            </div>
            <div id="posts-template" class="hidden flex flex flex-wrap gap-5 w-full mx-5">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.posts.post-card','data' => ['post' => $post]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('posts.post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $attributes = $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $component = $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="likes-template" class="hidden flex flex-wrap gap-5 w-full mx-5">
                <?php $__currentLoopData = $reactionPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.posts.post-card','data' => ['post' => $post]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('posts.post-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['post' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $attributes = $__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__attributesOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e)): ?>
<?php $component = $__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e; ?>
<?php unset($__componentOriginalee79e636c220d7ebbd52bd5d3dfc300e); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="challenges-template" class="hidden flex flex-col m-5">
                    <h2 class="text-2xl font-bold text-gray-800">進行中のチャレンジ</h2>
                    <div class="flex items-center m-2 gap-2">
                        <div class="bg-blue-600 rounded-full h-3 w-3"></div>
                        <p class="text-sm text-blue-600 w-fit"><?php echo e($challenges->count()); ?>challenges</p>
                    </div>
                <div class="flex flex-wrap gap-5 w-full m-5">
                    <?php $__currentLoopData = $challenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalb9dd77e9bec0d2a40ccd34355829f4e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9dd77e9bec0d2a40ccd34355829f4e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.challenges.challenge-public-ongoing-card','data' => ['challenge' => $challenge]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('challenges.challenge-public-ongoing-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['challenge' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($challenge)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9dd77e9bec0d2a40ccd34355829f4e1)): ?>
<?php $attributes = $__attributesOriginalb9dd77e9bec0d2a40ccd34355829f4e1; ?>
<?php unset($__attributesOriginalb9dd77e9bec0d2a40ccd34355829f4e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9dd77e9bec0d2a40ccd34355829f4e1)): ?>
<?php $component = $__componentOriginalb9dd77e9bec0d2a40ccd34355829f4e1; ?>
<?php unset($__componentOriginalb9dd77e9bec0d2a40ccd34355829f4e1); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const buttons = document.querySelectorAll('#timeSelector button');
            const indicator = document.getElementById('indicator');
            const templates = {
                posts: document.getElementById('posts-template'),
                likes: document.getElementById('likes-template'),
                challenges: document.getElementById('challenges-template'),
            }

            function modeIndicator(btn) {
                const offsetLeft = btn.offsetLeft;
                const offsetWidth = btn.offsetWidth;
                indicator.style.left = offsetLeft + 'px';
                indicator.style.width = offsetWidth + 'px';
            }

            modeIndicator(buttons[0]);
            buttons[0].classList.add('text-white');
            templates['posts'].classList.remove('hidden');
            // content.innerHTML = document.getElementById(buttons[0].dataset.template).innerHTML;

            buttons.forEach(button => {
                button.addEventListener('click', async () => {
                    const target = button.dataset.target;
                    //buttonUIの挙動
                    modeIndicator(button);
                    buttons.forEach(button => {
                        button.classList.remove('bg-white', 'text-white');
                        button.classList.add('text-gray-800');
                    });
                    button.classList.remove('text-gray-800');
                    button.classList.add('text-white');
                    //contentの挙動
                    Object.values(templates).forEach(t => t.classList.add('hidden')); //tはemplateの略
                    templates[target].classList.remove('hidden');
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/mypage.blade.php ENDPATH**/ ?>